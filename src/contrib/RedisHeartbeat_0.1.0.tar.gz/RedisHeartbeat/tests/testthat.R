library(testthat)
library(RedisHeartbeat)

test_check("RedisHeartbeat")
