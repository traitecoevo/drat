library(testthat)
library(baad.data)

test_check("baad.data")
