library(testthat)
library(tree)

test_check("tree")
