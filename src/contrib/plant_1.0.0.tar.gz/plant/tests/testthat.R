library(testthat)
library(plant)

test_check("plant")
