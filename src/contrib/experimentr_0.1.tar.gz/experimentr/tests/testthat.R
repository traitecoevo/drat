library(testthat)
library(experimentr)

test_check("experimentr")
