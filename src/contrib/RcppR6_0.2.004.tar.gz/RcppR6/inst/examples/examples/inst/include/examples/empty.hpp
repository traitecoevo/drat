#ifndef _EXAMPLES_EMPTY_HPP_
#define _EXAMPLES_EMPTY_HPP_

namespace examples {

class empty {
};

}

#endif
