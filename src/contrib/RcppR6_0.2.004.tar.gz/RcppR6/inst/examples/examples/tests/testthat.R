library(testthat)
library(examples)

test_check("examples")
