library(testthat)
library(dockertest)

test_check("dockertest")
