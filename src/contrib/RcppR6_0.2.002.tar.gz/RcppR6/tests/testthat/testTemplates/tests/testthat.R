library(testthat)
library(pair)

test_check("pair")
