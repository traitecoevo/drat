#ifndef _TESTEXAMPLES_SIMPLE_HPP_
#define _TESTEXAMPLES_SIMPLE_HPP_

// Some very simple classes

namespace examples {

namespace simple {

// Corner case: this has no constructor/fields/methods, etc.
class empty {
};

}

}

#endif
