#' Examples Package
#'
#' @name examples
#' @docType package
NULL
