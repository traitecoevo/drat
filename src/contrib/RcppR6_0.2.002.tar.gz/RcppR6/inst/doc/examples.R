## ----echo=FALSE, results="asis"------------------------------------------
set.seed(1)
source(system.file("vignette_common.R", package="RcppR6"))
path <- vignette_prepare("examples")
plain_output(tree(path, "introduction"))

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(readLines(file.path(path, "inst/RcppR6.yml")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/examples/uniform.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(readLines(file.path(path, "inst/uniform.yml")))

## ----echo=FALSE, results="asis"------------------------------------------
yaml <- yaml <- readLines(file.path(path, "inst/uniform.yml"))
i_constructor <- grep("\\s+constructor:", yaml)[[1]]
i_methods <- grep("\\s+methods:", yaml)[[1]]
i_active <- grep("\\s+active:", yaml)[[1]]
yaml_output(yaml[i_constructor:(i_methods - 1)])

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(yaml[i_methods:(i_active - 1)])

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(yaml[i_active:length(yaml)])

## ------------------------------------------------------------------------
RcppR6::install(path)

## ------------------------------------------------------------------------
devtools::document(path)

## ------------------------------------------------------------------------
devtools::load_all(path)

## ------------------------------------------------------------------------
u <- uniform()
u

## ------------------------------------------------------------------------
u$draw(10)

## ------------------------------------------------------------------------
u$u

## ------------------------------------------------------------------------
u$min
u$max
args(uniform)

## ----error=TRUE----------------------------------------------------------
u$min <- 100
u$max <- 200

## ------------------------------------------------------------------------
u$the_min <- 10
u$the_max <- 20

## ------------------------------------------------------------------------
u$the_min
u$the_max

## ------------------------------------------------------------------------
u$u

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/examples/stack.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(readLines(file.path(path, "inst/stack.yml")))

## ------------------------------------------------------------------------
s <- stack()

## ------------------------------------------------------------------------
s$top

## ----error=TRUE----------------------------------------------------------
s$pop()

## ------------------------------------------------------------------------
s$push(1)
s$push(10)
s$push(100)

## ------------------------------------------------------------------------
s$size

## ------------------------------------------------------------------------
s$top

## ------------------------------------------------------------------------
s$pop()

s$top

## ------------------------------------------------------------------------
while (!s$empty) {
  s$pop()
}
s$size

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/examples/empty.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(readLines(file.path(path, "inst/empty.yml")))

## ------------------------------------------------------------------------
e <- empty()
e

