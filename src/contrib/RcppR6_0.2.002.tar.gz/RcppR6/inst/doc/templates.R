## ----echo=FALSE, results="asis"------------------------------------------
set.seed(1)
source(system.file("vignette_common.R", package="RcppR6"))
path <- vignette_prepare("templates")
cpp_output(readLines(file.path(path, "inst/include/templates/pair1.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
yaml <- readLines(file.path(path, "inst/RcppR6_classes.yml"))
i_pair2 <- grep("pair2:", yaml)
yaml1 <- yaml[1:(i_pair2 - 2)]
yaml2 <- yaml[i_pair2:length(yaml)]
i_templates <- grep("\\s+templates:", yaml1)[[1]]
i_constructor <- grep("\\s+constructor:", yaml1)[[1]]
i_active <- grep("\\s+active:", yaml1)[[1]]
yaml_output(yaml1)

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(yaml1[i_templates:(i_constructor - 1)])

## ------------------------------------------------------------------------
RcppR6::install(path)

## ------------------------------------------------------------------------
devtools::document(path)

## ------------------------------------------------------------------------
devtools::load_all(path)

## ------------------------------------------------------------------------
args(pair1)

## ------------------------------------------------------------------------
args(pair1("int"))

## ------------------------------------------------------------------------
p <- pair1("int")(1L, 2L)

## ------------------------------------------------------------------------
p$first
p$first <- 10
p$second
p$second <- 20

## ----error=TRUE----------------------------------------------------------
p$second <- "second"
p$second

## ------------------------------------------------------------------------
class(p)

## ------------------------------------------------------------------------
p_double <- pair1("double")(exp(1), pi)
p_double$first
p_double$second
class(p_double)

## ------------------------------------------------------------------------
p_string <- pair1("string")("first", "second")
p_string$first
p_string$second
class(p_string)

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(yaml2)

## ------------------------------------------------------------------------
args(pair2)

## ------------------------------------------------------------------------
p2 <- pair2("int", "double")(1L, pi)
p2$first
p2$second

## ------------------------------------------------------------------------
p2 <- pair2("string", "double")("first", pi)
p2$first
p2$second

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/templates/RcppR6_pre.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/templates/RcppR6_post.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/templates/RcppR6_support.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
r_output(readLines(file.path(path, "R/RcppR6.R")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "src/RcppR6.cpp")))

