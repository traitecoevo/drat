## ----echo=FALSE----------------------------------------------------------
set.seed(1)
source(system.file("vignette_common.R", package="RcppR6"))
path <- vignette_prepare("introduction")

## ----echo=FALSE, results="asis"------------------------------------------
cls <- readLines(file.path(path, "inst/include/introduction.h"))
i1 <- grep("^#include", cls)[[1]]
i2 <- grep("^};", cls)[[1]]
cpp_output(cls[i1:i2])

## ----echo=FALSE, results="asis"------------------------------------------
tree <- function(path, header=path) {
  paste1 <- function(a, b) {
    paste(rep_len(a, length(b)), b)
  }
  indent <- function(x, files) {
    paste0(if (files) "| " else "  ", x)
  }
  is_directory <- function(x) {
    unname(file.info(x)[, "isdir"])
  }
  prefix_file <- "|--="
  prefix_dir  <- "|-+="

  files <- dir(path)
  files_full <- file.path(path, files)
  isdir <- is_directory(files_full)

  ret <- as.list(c(paste1(prefix_dir, files[isdir]),
                   paste1(prefix_file, files[!isdir])))
  files_full <- c(files_full[isdir], files_full[!isdir])
  isdir <- c(isdir[isdir], isdir[!isdir])

  n <- length(ret)
  ret[[n]] <- sub("|", "\\", ret[[n]], fixed=TRUE)
  tmp <- lapply(which(isdir), function(i)
    c(ret[[i]], indent(tree(files_full[[i]], NULL), !all(isdir))))
  ret[isdir] <- tmp

  c(header, unlist(ret))
}
plain_output(tree(path, "introduction"))

## ----echo=FALSE, results="asis"------------------------------------------
yaml <- readLines(file.path(path, "inst/RcppR6_classes.yml"))
yaml_output(yaml)

## ----echo=FALSE, results="asis"------------------------------------------
i_constructor <- grep("\\s+constructor:", yaml)[[1]]
i_methods <- grep("\\s+methods:", yaml)[[1]]
i_active <- grep("\\s+active:", yaml)[[1]]
yaml_output(yaml[i_constructor:(i_methods - 1)])

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(yaml[i_methods:(i_active - 1)])

## ----echo=FALSE, results="asis"------------------------------------------
yaml_output(yaml[i_active:length(yaml)])

## ----echo=FALSE, results="asis"------------------------------------------
dat <- RcppR6:::yaml_load(paste(yaml, collapse="\n"))
yaml_output(yaml::as.yaml(dat$circle$active["radius"]))

## ----echo=FALSE, results="asis"------------------------------------------
tmp <- grep("^//", cls, value=TRUE, invert=TRUE)
cpp_output(gsub("\n\n+", "\n\n", paste(tmp, collapse="\n")))

## ----echo=FALSE, results="asis"------------------------------------------
plain_output(readLines(file.path(path, "DESCRIPTION")))

## ------------------------------------------------------------------------
RcppR6::install(path)

## ----echo=FALSE, results="asis"------------------------------------------
plain_output(tree(path, "introduction"))

## ----echo=FALSE, results="asis"------------------------------------------
plain_output(readLines(file.path(path, "DESCRIPTION")))

## ----echo=FALSE, results="asis"------------------------------------------
plain_output(readLines(file.path(path, "src/Makevars")))

## ------------------------------------------------------------------------
devtools::document(path)

## ------------------------------------------------------------------------
devtools::load_all(path)

## ------------------------------------------------------------------------
obj <- circle(1.0)
obj

## ------------------------------------------------------------------------
class(obj)

## ------------------------------------------------------------------------
obj$.ptr

## ------------------------------------------------------------------------
obj$initialize

## ------------------------------------------------------------------------
obj$area()
obj$area() - pi

## ------------------------------------------------------------------------
obj$radius

## ------------------------------------------------------------------------
obj$radius <- 2
obj$radius
obj$area()

## ------------------------------------------------------------------------
obj$circumference <- 1.0
obj$circumference
obj$radius

## ----error=TRUE----------------------------------------------------------
obj$circumference <- -1

## ------------------------------------------------------------------------
system.time(RcppR6::RcppR6(path))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/introduction/RcppR6_pre.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/introduction/RcppR6_post.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "inst/include/introduction/RcppR6_support.hpp")))

## ----echo=FALSE, results="asis"------------------------------------------
r_output(readLines(file.path(path, "R/RcppR6.R")))

## ----echo=FALSE, results="asis"------------------------------------------
cpp_output(readLines(file.path(path, "src/RcppR6.cpp")))

