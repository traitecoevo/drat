// -*-c++-*-
#ifndef _TEMPLATES_H_
#define _TEMPLATES_H_

#include <templates/pair1.hpp>
#include <utility> // for std::pair
#include <templates/RcppR6_pre.hpp>
#include <templates/RcppR6_post.hpp>

#endif
