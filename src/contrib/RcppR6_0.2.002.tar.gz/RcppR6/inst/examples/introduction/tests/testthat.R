library(testthat)
library(circle)

test_check("circle")
