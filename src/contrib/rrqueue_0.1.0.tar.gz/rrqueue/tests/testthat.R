library(testthat)
library(rrqueue)

test_check("rrqueue")
