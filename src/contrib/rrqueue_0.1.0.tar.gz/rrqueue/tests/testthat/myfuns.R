slowdouble <- function(x) {
  Sys.sleep(x)
  x * 2
}

suml <- function(x) {
  x[[1]] + x[[2]]
}

prod2 <- function(a, b) {
  a * b
}
