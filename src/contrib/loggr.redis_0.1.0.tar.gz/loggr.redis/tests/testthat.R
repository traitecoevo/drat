library(testthat)
library(loggr.redis)

test_check("loggr.redis")
