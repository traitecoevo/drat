## ------------------------------------------------------------------------
library(RedisAPI)

## ----, echo=FALSE, results="hide"----------------------------------------
# cleanup:
library(RcppRedis)
RedisAPI::hiredis()$DEL(c("mykey", "mylist", "mylist2"))

## ------------------------------------------------------------------------
r <- RedisAPI::hiredis()

## ------------------------------------------------------------------------
r$SET("mykey", "mydata") # set the key "mykey" to the value "mydata"
r$GET("mykey")

## ------------------------------------------------------------------------
s <- object_to_string(1:10)
s # ew. but this does encode everything about this object
string_to_object(s) # here's the original back

## ------------------------------------------------------------------------
r$SET("mylist", object_to_string(1:10))
r$GET("mylist")
string_to_object(r$GET("mylist"))

## ------------------------------------------------------------------------
r$RPUSH("mylist2", 1:10)

## ------------------------------------------------------------------------
r$LINDEX("mylist2", 1)

## ------------------------------------------------------------------------
r$LSET("mylist2", 1, "carrot")

## ------------------------------------------------------------------------
r$LRANGE("mylist2", 0, -1)

## ------------------------------------------------------------------------
r$LRANGE("mylist2", 0, 2)

## ------------------------------------------------------------------------
r$LLEN("mylist2")
r$LPOP("mylist2")
r$RPOP("mylist2")
r$LLEN("mylist2")

## ------------------------------------------------------------------------
r$LPUSH("mylist2", object_to_string(1:10))

## ------------------------------------------------------------------------
dat <- r$LRANGE("mylist2", 0, 2)
dat
dat[[1]] <- string_to_object(dat[[1]])
dat

## ------------------------------------------------------------------------
db <- rdb(hiredis)

## ------------------------------------------------------------------------
db$keys()

## ------------------------------------------------------------------------
db$set("mykey", 1:10)
db$keys()

## ------------------------------------------------------------------------
db$get("mykey")

## ------------------------------------------------------------------------
db$get("no_such_key")

## ------------------------------------------------------------------------
db$set("mtcars", mtcars)
identical(db$get("mtcars"), mtcars)
db$set("a_function", sin)
db$get("a_function")(pi / 2) # 1

## ------------------------------------------------------------------------
rlist <- function(..., key=NULL, r=RedisAPI::hiredis()) {
  if (is.null(key)) {
    key <- paste(sample(letters, 32, replace=TRUE), collapse="")
  }
  dat <- vapply(c(...), object_to_string, character(1))
  r$RPUSH(key, dat)
  ret <- list(r=r, key=key)
  class(ret) <- "rlist"
  ret
}

## ------------------------------------------------------------------------
length.rlist <- function(x) {
  x$r$LLEN(x$key)
}

`[[.rlist` <- function(x, i, ...) {
  string_to_object(x$r$LINDEX(x$key, i - 1L))
}

`[[<-.rlist` <- function(x, i, value, ...) {
  x$r$LSET(x$key, i - 1L, object_to_string(value))
  x
}

## ------------------------------------------------------------------------
obj <- rlist(1:10)
length(obj) # 10
obj[[3]]
obj[[3]] <- "an element"
obj[[3]]

## ------------------------------------------------------------------------
obj2 <- obj
obj2[[2]] <- obj2[[2]] * 2
obj[[2]] == obj2[[2]]

## ----, echo=FALSE, results="hide"----------------------------------------
# cleanup:
r$DEL(c("mykey", "mylist", "mylist2"))

