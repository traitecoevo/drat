library(testthat)
library(RedisAPI)

test_check("RedisAPI")
