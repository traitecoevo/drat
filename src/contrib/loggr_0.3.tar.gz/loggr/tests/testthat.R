library(testthat)
library(loggr)

test_check("loggr")
