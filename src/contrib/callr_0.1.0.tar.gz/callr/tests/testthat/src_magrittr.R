## A functional sequence that causes so much trouble!
s <- . %>% sort
