f <- function(x) {
  2 * x
}
