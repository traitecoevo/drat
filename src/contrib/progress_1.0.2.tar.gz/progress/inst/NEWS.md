
# 1.0.2

* Fix the C++ API on Windows, and on older compilers in general.

# 1.0.1

First version on CRAN.
