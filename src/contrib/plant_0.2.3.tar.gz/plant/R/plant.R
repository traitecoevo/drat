## Support functions for growing a plant to a given size, etc.  Used
## in dfalster/TraitGrowthTrajectories

##' Grow a plant up to particular sizes.
##'
##' @title Grow plant to given size
##' @param plant A \code{Plant} object.
##' @param sizes A vector of sizes to grow the plant to (increasing in
##' size).
##' @param size_name The name of the size variable within
##' \code{Plant$vars_phys} (e.g., height).
##' @param env An \code{Environment} object.
##' @param time_max Time to run the ODE out for -- only exists to
##' prevent an infinite loop (say, on an unreachable size).
##' @param warn Warn if requesting a plant that is too large?
##' @param filter Filter plants that are too large?
##' @return A list with elements \code{time} (the time that a given
##' size was reached), \code{state} (the \emph{ode state} at these
##' times, as a matrix) and \code{plant} a list of plants grown to the
##' appropriate size.  Note that if only a single size is given,
##' a list of length 1 is returned.
##' @export
grow_plant_to_size <- function(plant, sizes, size_name, env,
                               time_max=Inf, warn=TRUE, filter=FALSE) {
  obj <- grow_plant_bracket(plant, sizes, size_name, env, time_max, warn)

  polish <- function(i) {
    grow_plant_bisect(obj$runner, sizes[[i]], size_name,
                      obj$t0[[i]], obj$t1[[i]], obj$y0[i, ])
  }
  res <- lapply(seq_along(sizes), polish)

  state <- t(sapply(res, "[[", "state"))
  colnames(state) <- colnames(obj$state)

  ret <- list(time=vnapply(res, "[[", "time"),
              state=state,
              plant=lapply(res, "[[", "plant"),
              trajectory=cbind(time=obj$time, state=obj$state),
              env=env)
  if (filter) {
    i <- !vlapply(ret$plant, is.null)
    if (!all(i)) {
      ret$time  <- ret$time[i]
      ret$state <- ret$state[i, , drop=FALSE]
      ret$plant <- ret$plant[i]
    }
  }
  ret
}

##' @export
##' @rdname grow_plant_to_size
##' @param ... Additional parameters passed to
##' \code{grow_plant_to_size}.
##' @param heights Heights (when using \code{grow_plant_to_height})
grow_plant_to_height <- function(plant, heights, env, ...) {
  grow_plant_to_size(plant, heights, "height", env, ...)
}

##' Grow a plant up for particular time lengths
##'
##' @title Grow a plant
##' @param plant A \code{Plant} object
##' @param times A vector of times
##' @param env An \code{Environment} object
##' @export
grow_plant_to_time <- function(plant, times, env) {
  if (any(times < 0.0)) {
    stop("Times must be positive")
  }
  n <- length(times)
  if (n == 0L) {
    stop("At least one time must be given")
  }

  y0 <- plant$ode_state
  t0 <- 0.0
  i <- 1L
  t_next <- times[[i]]
  runner <- OdeRunner("PlantRunner")(PlantRunner(plant, env))
  runner_detail <- OdeRunner("PlantRunner")(PlantRunner(plant, env))

  ## TODO: This could also be done by better configuring the
  ## underlying ODE runner, but this seems a reasonable way of getting
  ## things run for now.
  state <- matrix(NA, n, length(y0))
  colnames(state) <- plant$ode_names

  plant <- vector("list", n)
  while (i <= n) {
    runner$step()
    t1 <- runner$time
    y1 <- runner$state
    while (t_next < t1 && i <= n) {
      runner_detail$set_state(y0, t0)
      runner_detail$step_to(t_next)
      state[i, ] <- runner_detail$state
      plant[[i]] <- runner_detail$object$plant
      i <- i + 1L
      t_next <- times[i] # allows out-of-bounds extraction
    }
    t0 <- t1
    y0 <- y1
  }

  list(time=times, state=state, plant=plant, env=env)
}

grow_plant_bracket <- function(plant, sizes, size_name, env,
                               time_max=Inf, warn=TRUE) {
  if (length(sizes) == 0L || is.unsorted(sizes)) {
    stop("sizes must be non-empty and sorted")
  }
  if (plant$internals[[size_name]] > sizes[[1]]) {
    stop("Plant already bigger than smallest target size")
  }

  runner <- OdeRunner("PlantRunner")(PlantRunner(plant, env))
  i <- 1L
  n <- length(sizes)
  j <- rep_len(NA_integer_, n)
  state <- list(list(time=runner$time, state=runner$state))

  while (i <= n & runner$time < time_max) {
    runner$step()
    state <- c(state, list(list(time=runner$time, state=runner$state)))
    while (i <= n && oderunner_plant_size(runner)[[size_name]] > sizes[[i]]) {
      j[[i]] <- length(state) - 1L
      i <- i + 1L
    }
    if (runner$time >= time_max) {
      if (warn) {
        warning(sprintf("Time exceeded time_max, %d larger sizes dropped",
                        sum(is.na(j))), immediate.=TRUE)
      }
      break
    }
  }

  t <- vnapply(state, "[[", "time")
  m <- t(sapply(state, "[[", "state"))
  k <- j + 1L
  colnames(m) <- runner$object$plant$ode_names
  list(t0=t[j],
       t1=t[k],
       y0=m[j, , drop=FALSE],
       y1=m[k, , drop=FALSE],
       time=t,
       state=m,
       index=j,
       runner=runner)
}

grow_plant_bisect <- function(runner, size, size_name, t0, t1, y0) {
  f <- function(t1) {
    runner$set_state(y0, t0)
    runner$step_to(t1)
    oderunner_plant_size(runner)[[size_name]] - size
  }

  if (is.na(t0) || is.na(t1) || any(is.na(y0))) {
    y0[] <- NA_real_
    list(time=NA_real_, state=y0, plant=NULL)
  } else {
    root <- uniroot(f, lower=t0, upper=t1)
    list(time=root$root, state=runner$state, plant=runner$object$plant)
  }
}
