library(testthat)
library(testREADME)

test_check("testREADME")
