library(testthat)
library(RcppR6)

test_check("RcppR6")
